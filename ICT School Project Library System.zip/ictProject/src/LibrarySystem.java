/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aldrin-Du
 */
import guis.*;
public class LibrarySystem {
    public static void main(String[] args){
        Login_interface panel = new Login_interface();
        panel.setVisible(true);
    }
}
